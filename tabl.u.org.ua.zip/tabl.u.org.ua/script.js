const $question = jQuery(".item .item_header");
  $question.on("click", function(e) {
    e.preventDefault();
    const $this = jQuery(this);
    $question.removeClass("open");
    if ($this.next().hasClass("show")) {
      $this.next().removeClass("show");
      $this.removeClass("open"); 
      $this.next().slideUp(600);  


    } else {
      $this
       .parent()
        .parent()
        .parent()
        .find(".item_descr")
        .removeClass("show");
      $this.removeClass("open");

      $this
       .parent()
        .parent()
        .parent()
        .find(".item_descr")
        .slideUp(600);
      $this.next().toggleClass("show");
      $this.toggleClass("open");
      $this.next().slideToggle(600);
  
    }
  
  });  

 jQuery(".item_header").click(function(){    
   jQuery(".arrow").removeClass("arrow_active");
   let flag = jQuery(".item_descr").hasClass("show");
   if(flag) { jQuery(this).find(".arrow").addClass("arrow_active");}
 }); 