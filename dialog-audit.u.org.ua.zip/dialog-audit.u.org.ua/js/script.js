
  var smoothJumpUp = function() {
    if (document.body.scrollTop > 0 || document.documentElement.scrollTop > 0) {
        window.scrollBy(0,-50);
        setTimeout(smoothJumpUp, 10);
    }
}

window.onscroll = function() {
  var scrolled = window.pageYOffset || document.documentElement.scrollTop;
  if (scrolled > 100) {
    document.getElementById('upbutton').style.display = 'flex';
  } else {
    document.getElementById('upbutton').style.display = 'none';
  }
}
jQuery('.input').change(function () { 
  jQuery(this).next('.label').addClass('filled');         
});
  var swiper = new Swiper(".mySwiper", {
    pagination: {
      el: ".swiper-pagination",
    },
  });
  var swiper = new Swiper(".mySwiper2", {
    pagination: {
      el: ".swiper-pagination",
    },
  });
  jQuery(document).ready(function(){
    if (jQuery(window).width() < 992) {
        jQuery('.header .burger-menu').click(function () {
        jQuery(this).toggleClass('open');
        jQuery('.header .mob').slideToggle();
        if (jQuery(this).hasClass("open")){
            jQuery('body').css('overflow', 'hidden');
        }
        else {
            jQuery('body').css('overflow', 'auto');
        }
    });
  
    jQuery('.header  .mob li a').click(function(){
	  jQuery('.header .mob').slideToggle();
      jQuery('.header  .burger-menu').toggleClass('open');
    });
      } 
jQuery('a').on( 'click', function(){ 
    var el = jQuery(this);
    var dest = el.attr('href');
    if(dest !== undefined && dest !== '') {
        jQuery('html').animate({ 
    	    scrollTop: jQuery(dest).offset().top
        }, 1000 
        );
    }
    return false;
});

});