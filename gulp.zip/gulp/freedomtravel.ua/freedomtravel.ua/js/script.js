function testWebP(callback) {
	var webP = new Image();
	webP.onload = webP.onerror = function () {
		callback(webP.height == 2);
	};
	webP.src = "data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA";
}
testWebP(function (support) {
	if (support == true) {
		document.querySelector('html').classList.add('_webp');
	} else {
		document.querySelector('html').classList.add('_no-webp');
	}
});
jQuery(document).ready(function(){
    if (jQuery(window).width() < 900) {
        jQuery(".intro").scroll(function() {
			if (jQuery(".intro").scrollTop() > 30) {
			  jQuery(".header-zag").addClass("sticky");
			} else {
			  jQuery(".header-zag").removeClass("sticky");
			}
		});
        
    }
});

  
    



